import json

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import request
from django.shortcuts import redirect, render
from django.template import context
from django.utils import timezone

from employees.models import Employee
from tasks.models import Task

from .models import Project


def _project_stats():
    today = timezone.now().date()

    return {
        "total_projects": Project.objects.count(),
        "active_projects": Project.objects.filter(status="in_progress").count(),
        "completed_projects": Project.objects.filter(status="completed").count(),
        "overdue_projects": Project.objects.filter(
            end_date__lt=today
        ).exclude(status="completed").count(),
    }


def _resolve_assignee_user(assignee_details_raw):
    if not assignee_details_raw:
        return None, None

    try:
        details = json.loads(assignee_details_raw)
    except json.JSONDecodeError:
        return None, None

    employee = Employee.objects.filter(
        employee_id=details.get("empId", "")
    ).first()

    if employee:
        return employee, details

    return None, details


@login_required
def Myprojects(request):

    projects = Project.objects.filter(
        employee=request.user,
        project_type="Project"
    ).order_by("-created_at")

    context = {
        "projects": projects,
        "total_projects": projects.count(),
    }

    return render(
        request,
        "projects/Myprojects.html",
        context,
    )

@login_required
def create_project(request):
    manager = Employee.objects.filter(user=request.user).first()

    if manager is None:
        messages.error(request, "Manager profile not found.")
        return redirect("login")

    team_leads = Employee.objects.filter(role="Team Lead").order_by("department")
    employees = Employee.objects.filter(role="Employee").order_by("user__first_name")
    existing_projects = Project.objects.order_by("-created_at")

    context = {
        "team_leads": team_leads,
        "employees": employees,
        "existing_projects": existing_projects,
        **_project_stats(),
    }

    if request.method == "POST":
        project_type = request.POST.get("projectType")
        title = request.POST.get("title", "").strip()
        description = request.POST.get("description", "").strip()
        start_date = request.POST.get("start_date")
        end_date = request.POST.get("end_date") or start_date
        attachment = request.FILES.get("attachment")
        linked_project_id = request.POST.get("linked_project")
        assignee_details_raw = request.POST.get("assigneeDetails", "")

        employee_obj, details = _resolve_assignee_user(assignee_details_raw)
        assignee_user = employee_obj.user if employee_obj else None
        assignee_role = (details or {}).get("role", "")

        if not title or not description or not start_date:
            messages.error(request, "Please fill in all required fields.")
            return render(request, "projects/create_project.html", context)

        if not assignee_user:
            messages.error(request, "Please submit valid assignee details.")
            return render(request, "projects/create_project.html", context)

        if project_type == "Project":

            project = Project.objects.create(
                project_type="Project",
                project_name=title,
                description=description,
                employee=assignee_user,
                role=assignee_role,
                status="pending",
                start_date=start_date,
                end_date=end_date,
            )

            Task.objects.create(
                project=project,
                employee=employee_obj,
                title=title,
                description=description,
                due_date=end_date,
                status="Pending",
            )

            messages.success(
                request,
                f'Project "{title}" assigned successfully.'
            )

            return redirect("create_project")

        if project_type == "Task":
            if not linked_project_id:
                messages.error(request, "Please select a project for this task.")
                return render(request, "projects/create_project.html", context)

            project = Project.objects.filter(id=linked_project_id).first()
            if project is None:
                messages.error(request, "Selected project was not found.")
                return render(request, "projects/create_project.html", context)

            if employee_obj is None:
                messages.error(request, "Task assignee must be a valid employee.")
                return render(request, "projects/create_project.html", context)

            task = Task.objects.create(
                project=project,
                employee=employee_obj,
                title=title,
                description=description,
                due_date=end_date or start_date,
                status="Pending",
            )

            if attachment:
                task.attachment = attachment
                task.save()

            messages.success(request, f'Task "{title}" assigned successfully.')
            return redirect("create_project")

    if request.method == "GET":
       return render(request, "projects/create_project.html", context)

   
    return render(request, "projects/create_project.html", context)

    
